<?php 
/**
 * Error Panel
 */
global $woo_options, $panel_error_message; ?>
<div <?php post_class(); ?>>
	<p class="woo-sc-box note"><?php echo $panel_error_message; ?></p>
</div><!-- /.post -->